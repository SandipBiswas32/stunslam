package dev.lvstrng.argon.font;

public final class Fonts {
	public static GlyphPageFontRenderer QUICKSAND = GlyphPageFontRenderer.createFromID("/assets/argon/font/font.ttf", 40, false, false, false);
}
