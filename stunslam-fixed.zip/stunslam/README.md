# Stun Slam

Client-side Fabric mod for Minecraft 1.21.11 (Yarn mappings, Loom 1.14).

When the entity you attack is blocking with a shield:
- holding a sword + axe in hotbar: hits with the axe (shield disable), then a mace smash if you are airborne, then returns to your original slot
- holding an axe while airborne + mace in hotbar: after your hit, follows up with the mace

Many multiplayer servers ban automatic weapon switching. Use it only where it is allowed.

## Build
Push to GitHub, open Actions > build, download the `stunslam-jar` artifact.
Locally: `gradle build` (Gradle 9.2+, JDK 21). Jar is in `build/libs/`.
