package dev.sandip.stunslam.mixin.client;

import java.util.ArrayDeque;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.Hand;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayerInteractionManager.class)
public abstract class ClientPlayerInteractionManagerMixin {
    @Shadow @Final private MinecraftClient client;

    @Shadow protected abstract void syncSelectedSlot();

    /** True while WE are calling attackEntity, so the hook below ignores that call (prevents recursion). */
    @Unique private boolean stunslam$busy = false;

    /** Follow-up steps, one executed per client tick (replaces the old background thread + sleeps). */
    @Unique private final ArrayDeque<Runnable> stunslam$queue = new ArrayDeque<>();

    @Inject(method = "tick", at = @At("HEAD"))
    private void stunslam$tick(CallbackInfo ci) {
        if (stunslam$queue.isEmpty()) return;
        if (client.player == null || client.world == null) {
            stunslam$queue.clear();
            stunslam$busy = false;
            return;
        }
        stunslam$queue.poll().run();
    }

    @Inject(method = "attackEntity", at = @At("HEAD"), cancellable = true)
    private void stunslam$onAttack(PlayerEntity player, Entity target, CallbackInfo ci) {
        if (stunslam$busy || !stunslam$queue.isEmpty()) return;
        if (!(target instanceof LivingEntity living) || !stunslam$isBlocking(living)) return;

        ClientPlayerEntity self = client.player;
        if (self == null || player != self) return;

        ItemStack mainHand = self.getMainHandStack();
        boolean holdingSword = mainHand.isIn(ItemTags.SWORDS);
        boolean holdingAxe = mainHand.isIn(ItemTags.AXES);
        boolean airborne = !self.isOnGround();

        int axeSlot = stunslam$findHotbar(self, true);
        int maceSlot = stunslam$findHotbar(self, false);
        int originalSlot = self.getInventory().getSelectedSlot();

        if (holdingSword && axeSlot != -1) {
            // Sword in hand: hit with the axe instead (disables the shield), mace follows if airborne.
            ci.cancel();
            stunslam$select(self, axeSlot);
            stunslam$strike(self, target);
            if (airborne && maceSlot != -1) {
                stunslam$queueMace(maceSlot, target);
            }
            stunslam$queueRestore(originalSlot);
        } else if (holdingAxe && airborne && maceSlot != -1) {
            // Axe in hand: let this hit through, then follow up with the mace.
            stunslam$queueMace(maceSlot, target);
            stunslam$queueRestore(originalSlot);
        }
    }

    @Unique
    private void stunslam$queueMace(int maceSlot, Entity target) {
        stunslam$queue.add(() -> {
            ClientPlayerEntity p = client.player;
            if (p == null || target.isRemoved()) return;
            stunslam$select(p, maceSlot);
            stunslam$strike(p, target);
        });
    }

    @Unique
    private void stunslam$queueRestore(int originalSlot) {
        stunslam$queue.add(() -> {
            ClientPlayerEntity p = client.player;
            if (p == null) return;
            stunslam$select(p, originalSlot);
        });
    }

    @Unique
    private void stunslam$select(ClientPlayerEntity p, int slot) {
        p.getInventory().setSelectedSlot(slot);
        syncSelectedSlot();
    }

    @Unique
    private void stunslam$strike(ClientPlayerEntity p, Entity target) {
        stunslam$busy = true;
        try {
            ((ClientPlayerInteractionManager) (Object) this).attackEntity(p, target);
            p.swingHand(Hand.MAIN_HAND);
        } finally {
            stunslam$busy = false;
        }
    }

    @Unique
    private boolean stunslam$isBlocking(LivingEntity entity) {
        return entity.isUsingItem() && entity.getActiveItem().isOf(Items.SHIELD);
    }

    @Unique
    private int stunslam$findHotbar(ClientPlayerEntity p, boolean axe) {
        for (int i = 0; i < 9; i++) {
            ItemStack stack = p.getInventory().getStack(i);
            if (axe ? stack.isIn(ItemTags.AXES) : stack.isOf(Items.MACE)) {
                return i;
            }
        }
        return -1;
    }
}
